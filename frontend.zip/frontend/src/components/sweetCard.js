const SweetCard = ({ sweet }) => {
  return (
    <div className="border rounded-xl shadow p-4 bg-white hover:shadow-lg transition">
      <h2 className="text-xl font-bold">{sweet.name}</h2>
      <p>Category: {sweet.category}</p>
      <p>Price: ₹{sweet.price}</p>
      <p>In Stock: {sweet.quantity}</p>
      <button className="mt-2 px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600">
        Purchase
      </button>
    </div>
  );
};

export default SweetCard;
