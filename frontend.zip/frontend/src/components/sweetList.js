const SweetList = ({ sweets }) => {
  if (!sweets.length)
    return <p className="text-center text-gray-500">No sweets available</p>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {sweets.map((sweet) => (
        <div
          key={sweet._id}
          className="bg-white rounded-xl shadow-md p-6 hover:scale-105 transition-transform"
        >
          <h2 className="text-xl font-bold text-pink-600 mb-2">{sweet.name}</h2>
          <p className="text-gray-700 mb-1">
            <strong>Category:</strong> {sweet.category}
          </p>
          <p className="text-gray-700 mb-1">
            <strong>Price:</strong> ₹{sweet.price}
          </p>
          <p className="text-gray-700 mb-3">
            <strong>In Stock:</strong> {sweet.quantity}
          </p>
          <button className="bg-pink-500 hover:bg-pink-600 text-white py-2 px-4 rounded-md">
            Purchase
          </button>
        </div>
      ))}
    </div>
  );
};

export default SweetList;
