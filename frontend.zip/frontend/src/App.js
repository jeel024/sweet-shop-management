import { useEffect, useState } from 'react';
import { getAllSweets } from './api/sweetService';
import SweetList from './components/sweetList.js';
function App() {
  const [sweets, setSweets] = useState([]);

  useEffect(() => {
    getAllSweets().then(setSweets).catch(console.error);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-pink-500 text-white p-4 text-center text-2xl font-bold">
        Sweet Shop Management
      </header>
      <main className="p-4">
        <SweetList sweets={sweets} />
      </main>
    </div>
  );
}

export default App;
